<?php

$pdo = new PDO ('mysql:host=localhost;dbname=formulario','root','pretinha2002');
$sql = $pdo->prepare("SELECT * FROM usuarios");
$sql -> execute();

$fetchUsuarios = $sql -> fetchAll();

foreach($fetchUsuarios as $key=>$value){
    echo $value['ID']. ' | ' .$value['nome']. ' | ' .$value['email']. ' | ' .$value['ra']. ' | ' .$value['senha'] ;
    echo '<hr>';

}
