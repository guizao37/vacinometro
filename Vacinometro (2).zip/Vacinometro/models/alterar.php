<?php

    session_start();
    include_once('config.php');
    if(isset($_POST['alterar'])){
    
        $logado = $_SESSION['email'];

        $nome = $_POST['nome'];
        $sobrenome = $_POST['sobrenome'];
        $email = $_POST['email'];
        $ra = $_POST['ra'];
        $senha = $_POST['senha'];
        $vacinado = $_POST['vacinado'];

        if ($vacinado == 'nao') {
            $fabricante = "Selecione";
            $dose = "Não foi vacinado";
        } else {
            $fabricante = $_POST['fabricante'];
            $dose = $_POST['dose'];
        }

        $sqlUpdate = "UPDATE usuarios SET nome='$nome', sobrenome='$sobrenome', senha='$senha', vacinado='$vacinado', fabricante='$fabricante', dose='$dose' WHERE email='$logado'";

        $result = $conexao->query($sqlUpdate);



    }

    header(
        'Location: ../views/conta.php'
    )


?>
