<?php

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = 'pretinha2002';
$dbName = 'formulario';

$conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);



?>