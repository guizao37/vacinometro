<?php
session_start();
    if(isset($_POST['entrar']) && !empty($_POST['email']) && !empty($_POST['senha']))
    {
        include_once('../models/config.php');
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $ra = $_GET['ra'];
        $nome = $_GET['nome'];

        $sql = "SELECT * FROM usuarios WHERE email= '$email' and senha = '$senha'";

        $result = $conexao->query($sql);

        if (mysqli_num_rows($result) == 0) {
            unset($_SESSION['email']);
            unset($_SESSION['senha']);
            $erro = "E-mail ou senha inválidos";
            header('Location: ../views/index.php');
        }
        else {
            $_SESSION['email'] = $email;
            $_SESSION['senha'] = $senha;
            $_SESSION['nome'] = $nome;
            $_SESSION['ra'] = $ra;
            $_SESSION['vacinado'] = $vacinado;
            $_SESSION['fabricante'] = $fabricante;
            $_SESSION['dose'] = $dose;
            
            header('Location: ../views/sistema.php');
        }
    }

    else {
        header('Location: ../views/index.php');
    }


?>
