<?php
session_start();
if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    header(
        'Location: index.php'
    );
} else {
    $logado = $_SESSION['email'];
    include_once('../models/config.php');

    $mysql_result = "SELECT * FROM usuarios WHERE email='$logado'";
    $result = $conexao->query($mysql_result);

    if ($result->num_rows > 0) {
        while ($user_data = mysqli_fetch_assoc($result)) {
            $nome = $user_data['nome'];
            $sobrenome = $user_data['sobrenome'];
            $ra = $user_data['ra'];
            $email = $user_data['email'];
            $senha = $user_data['senha'];
            $vacinado = $user_data['vacinado'];
            $fabricante = $user_data['fabricante'];
            $dose = $user_data['dose'];
        }
    }
}
?>

<html>

<head>
    <meta charset="utf-8">
    <title>Vacinômetro PUC-SP</title>
    <link rel="stylesheet" type="text/css" href="../estilo/style.css">

    <script>
        function mostrar(x) {
            if (x == 1) {
                document.getElementById('mostrar').style.display = 'block';
            } else {
                document.getElementById('mostrar').style.display = 'none'
            }
        }
    </script>

</head>

<body>
    <script>
        const x = 0;
    </script>
    <div id="cabecalho">
        <img src="../imagens/puc.jpg" width="200px">
        <div id="menu">

            <form method="POST" action="../controllers/sair.php">
                <a href="sistema.php">INÍCIO</a>
                <a href="dados.php">DADOS</a>
                <a href="conta.php">CONTA</a>
                <input type="submit" name="sair" value="SAIR">
            </form>

        </div>

    </div>
    <div id="center">
        <div style="text-align: left; margin-bottom:30px;">
            <fieldset style="background-color: white; border:none;">
                <div class="dados">
                    <strong>
                        <h3 style="text-align: center; margin-bottom: 15px;">Seus dados</h3>
                    </strong>
                    <form action="../models/alterar.php" method="POST">
                        <fieldset style="border:none;">
                            <legend>Nome</legend>
                            <input type="text" name="nome" style="width: 430px; border-radius:2px; height:30px; font-size:20px" value=<?php echo $nome ?>>
                        </fieldset>
                </div>
                <div class="dados">
                    <fieldset style="border:none;">
                        <legend>Sobrenome</legend>
                        <input type="text" name="sobrenome" style="width: 430px; border-radius:2px; height:30px; font-size:20px" value="<?php echo $sobrenome ?>">
                    </fieldset>
                </div>
                <div class="dados">
                    <fieldset style="border:none;">
                        <legend>E-mail</legend>
                        <input type="text" name="email" style="width: 430px; border-radius:2px; height:30px; font-size:20px" value="<?php echo $email ?>" readonly>
                    </fieldset>
                </div>
                <div class="dados">
                    <fieldset style="border:none;">
                        <legend>Ra</legend>
                        <input type="text" name="ra" style="width: 430px; border-radius:2px; height:30px; font-size:20px" value="<?php echo $ra ?>" readonly>
                    </fieldset>
                </div>
                <div class="dados">
                    <fieldset style="border:none;">
                        <legend>Senha</legend>
                        <input type="password" name="senha" style="width: 430px; border-radius:2px; height:30px; font-size:20px" value="<?php echo $senha ?>">
                    </fieldset>
                </div>
                <div class="dados">
                    <fieldset style="border:none;">
                        <legend>Você já foi vacinado contra a covid-19?</legend>
                        <input type="radio" name="vacinado" value="sim" onclick="mostrar(1)" <?php echo ($vacinado == 'sim') ? 'checked' : '' ?>>
                        <label for="bool">Sim</label>
                        <input type="radio" name="vacinado" value="nao" onclick="mostrar(0)" <?php echo ($vacinado == 'nao') ? 'checked' : '' ?>>
                        <label>Não</label>
                    </fieldset>
                </div>
                <div id="mostrar" style="<?php if ($vacinado == 'nao') {echo "display: none;";} ?>">
                    <div class="dados">
                        <fieldset style="border:none;">
                            <legend>Fabricante</legend>
                            <select name="fabricante" style="width: 430px; height:30px; font-size:20px;">
                                <option value="" disabled selected><?php echo $fabricante; ?></option>
                                <option value="Astrazeneca / Oxford">Astrazeneca / Oxford</option>
                                <option value="Pfizer">Pfizer</option>
                                <option value="Coronavac">Coronavac</option>
                                <option value="Janssen">Janssen / Johnson & Johnson</option>
                                <option value="Outra">Outra</option>
                            </select>
                        </fieldset>
                    </div>
                    <div class="dados">
                        <fieldset style="border:none;">
                            <legend>Dose</legend>
                            <input type="radio" id="dose" name="dose" value="Primeira dose" <?php echo ($dose == 'Primeira dose') ? 'checked' : '' ?>>
                            <label for="primeira_dose">Primeira dose</label><br>
                            <input type="radio" id="dose" name="dose" value="Segunda dose" <?php echo ($dose == 'Segunda dose') ? 'checked' : '' ?>>
                            <label for="segunda_dose">Segunda dose</label><br>
                            <input type="radio" id="dose" name="dose" value="Terceira dose" <?php echo ($dose == 'Terceira dose') ? 'checked' : '' ?>>
                            <label for="terceira_dose">Terceira dose</label><br>
                            <input type="radio" id="dose" name="dose" value="Dose única" <?php echo ($dose == 'Dose única') ? 'checked' : '' ?>>
                            <label for="dose_unica">Dose única</label><br>
                        </fieldset>
                    </div>
                </div>
                <div class="dados" style="text-align: center;">
                    <input type="submit" name="alterar" style="width:100px;" value="SALVAR" class="button">
                </div>
        </div>
        </form>
    </div>
</body>

</html>