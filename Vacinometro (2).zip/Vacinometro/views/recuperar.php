<?php

use PHPMailer\PHPMailer\Exception;

function Rand_passwd( $length = 12, $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789' ) {
    return substr( str_shuffle( $chars ), 0, $length );
}
//Load Composer's autoloader
require('../vendor/autoload.php');

$mail = new PHPMailer\PHPMailer\PHPMailer();
if (isset($_POST['submit'])) {

    include_once('../models/config.php');
    $email = $_POST['email'];
    $ra = $_POST['ra'];
    $verifica = "SELECT * FROM usuarios WHERE email='$email' and ra='$ra'";

    $sql = $conexao->query($verifica);

    if (mysqli_num_rows($sql) == 0) {
        $msg = "E-mail ou RA incorretos";
        header('index.php');
    } else {
        $nova_senha = Rand_passwd();

        $sqlUpdate = "UPDATE usuarios SET senha='$nova_senha' WHERE email='$email'";

        $result = $conexao->query($sqlUpdate);
        $mail->isSMTP();        //Devine o uso de SMTP no envio
        $mail->SMTPAuth = true; //Habilita a autenticação SMTP
        $mail->Username   = '4d75641ce30ef2';
        $mail->Password   = 'ff44356aae97e1';

        // Criptografia do envio SSL também é aceito
        $mail->SMTPSecure = 'tls';

        // Informações específicadas pelo Google
        $mail->Host = 'smtp.mailtrap.io';
        $mail->Port = 2525;

        // Define o remetente
        $mail->setFrom('admin@vacinometro.com', 'Admin');
        // Define o destinatário
        $mail->addAddress($_POST['email'], 'Usuario');

        // Conteúdo da mensagem
        $mail->isHTML(true);
        $mail->Subject = 'Nova senha - Vacinometro PUC-SP';
        $mail->Body    = 'Ola! Essa e sua nova senha: '.$nova_senha;
        $mail->AltBody = 'Ola! Essa e sua nova senha: '.$nova_senha;

        // Enviar
        $mail->send();

        $msg = "Sua nova senha foi enviada";
    }
}
?>

<html>

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../estilo/style.css">
</head>

<body>
    <div id="cabecalho">
        <a href="index.php"><img src="../imagens/puc.jpg" width="200px"></a>
    </div>
    <div id="center" style="margin-top: 50px;">
        <form method="POST" action="recuperar.php">
            <fieldset style="width:100px;">
                <legend style="color: white;">Recuperação de senha</legend>
                <p style="color: white;">
                    <?php
                    if (isset($_POST['submit'])) {
                        echo $msg;
                    }
                    ?>
                </p>
                <input type="email" name="email" style="width:300px; height: 35px; margin-bottom:10px;"" placeholder=" Insira seu e-mail">
                <input type="text" name="ra" style="width:300px; height: 35px; margin-bottom:10px;"" placeholder=" Insira seu RA">
                <input type="submit" name="submit" class="form-submit-button" value="ENVIAR">
            </fieldset>
            <p id="back"><a href="index.php">Voltar ao início</a></p>
        </form>
    </div>
</body>

</html>