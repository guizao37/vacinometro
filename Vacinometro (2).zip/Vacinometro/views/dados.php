<?php
session_start();
if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
	unset($_SESSION['email']);
	unset($_SESSION['senha']);
	header(
		'Location: index.php'
	);
} else {
	$logado = $_SESSION['email'];
}

include_once('../models/config.php');
// NÚMERO TOTAL DE PESSOAS CADASTRADAS
$total = "SELECT * FROM usuarios";
$n_total = mysqli_num_rows($conexao->query($total));

// NÚMERO DE VACINADOS
$sim = "SELECT * FROM usuarios WHERE vacinado = 'sim' ";
$vacinados = mysqli_num_rows($conexao->query($sim));

// NÚMERO DE NÃO VACINADOS
$nao = "SELECT * FROM usuarios WHERE vacinado = 'nao' ";
$nao_vacinados = mysqli_num_rows($conexao->query($nao));

// ASTRAZENECA
$astrazeneca = "SELECT * FROM usuarios WHERE fabricante = 'Astrazeneca / Oxford' ";
$n_astrazeneca = mysqli_num_rows($conexao->query($astrazeneca));

// PFIZER
$pfizer = "SELECT * FROM usuarios WHERE fabricante = 'Pfizer' ";
$n_pfizer = mysqli_num_rows($conexao->query($pfizer));

// CORONAVAC
$coronavac = "SELECT * FROM usuarios WHERE fabricante = 'Coronavac' ";
$n_coronavac = mysqli_num_rows($conexao->query($coronavac));

// JANSSEN
$janssen = "SELECT * FROM usuarios WHERE fabricante = 'Janssen' ";
$n_janssen = mysqli_num_rows($conexao->query($janssen));

// OUTRAS
$outras = "SELECT * FROM usuarios WHERE fabricante = 'Outra' ";
$n_outras = mysqli_num_rows($conexao->query($outras));

// PRIMEIRA DOSE
$primeira_dose = "SELECT * FROM usuarios WHERE dose = 'Primeira dose' ";
$n_primeira_dose = mysqli_num_rows($conexao->query($primeira_dose));

// SEGUNDA DOSE
$segunda_dose = "SELECT * FROM usuarios WHERE dose = 'Segunda dose' ";
$n_segunda_dose = mysqli_num_rows($conexao->query($segunda_dose));

// TERCEIRA DOSE
$terceira_dose = "SELECT * FROM usuarios WHERE dose = 'Terceira dose' ";
$n_terceira_dose = mysqli_num_rows($conexao->query($terceira_dose));

// DOSE UNICA
$dose_unica = "SELECT * FROM usuarios WHERE dose = 'Dose única' ";
$n_dose_unica = mysqli_num_rows($conexao->query($dose_unica));

?>
<html>

<head>
	<meta charset="utf-8">
	<title>Dados - Vacinômetro PUC-SP</title>
	<link rel="stylesheet" type="text/css" href="../estilo/style.css">
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
	<div id="cabecalho">
		<img src="../imagens/puc.jpg" width="200px">
		<div id="menu">
			<form action="../controllers/sair.php" method="POST">
				<a href="sistema.php">INÍCIO</a>
				<a href="dados.php">DADOS</a>
				<a href="conta.php">CONTA</a>
				<input type="submit" name="sair" value="SAIR" class="button">
			</form>
		</div>
	</div>
	<div style="display:flex; justify-content:space-around; color:white;">

		<!-- Fabricante -->
		<div style="width: 400px; height:300px; padding-bottom:30px; margin-bottom:30px;">
			<h3 style="margin: 30px;">Dados sobre fabricantes</h3>
			<canvas id="myChart"></canvas>
		</div>

		<!-- Vacinados / Não vacinados -->
		<div style="width: 400px; height:300px; padding-bottom:30px">
			<h3 style="margin: 30px;">Dados sobre vacinados</h3>
			<canvas id="vacinados"></canvas>
		</div>

		<!-- Dose -->
		<div style="width: 400px; height:300px; padding-bottom:30px">
			<h3 style="margin: 30px;">Dados sobre doses</h3>
			<canvas id="dose"></canvas>
		</div>

	</div>
	<div style="text-align:center; color:white; margin-top:150px">
		USUÁRIOS CADASTRADOS:
		<?php echo $n_total;?>
	</div>
	<script>
		// DADOS PARA FABRICANTE
		const labels = [
			'Oxford / Astrazeneca',
			'Pfizer',
			'Coronavac',
			'Janssen',
			'Outras',
		];
		const data = {
			labels: labels,
			datasets: [{
				label: 'Fabricantes',
				backgroundColor: [
					'#ffba08',
					'#f48c06',
					'#dc2f02',
					'#9d0208',
					'#370617'
				],
				borderColor: '#1C1C1C',
				data: [<?php echo $n_astrazeneca ?>, <?php echo $n_pfizer ?>, <?php echo $n_coronavac ?>, <?php echo $n_janssen ?>, <?php echo $n_outras ?>],

			}]
		};
		const config = {
			type: 'pie',
			data: data,
			options: {}
		};
		// FIM DADOS PARA FABRICANTES

		// DADOS PARA VACINADOS
		const labels2 = [
			'Vacinados',
			'Não vacinados',
		];
		const data2 = {
			labels: labels2,
			datasets: [{
				label: 'Vacinados',
				backgroundColor: [
					'#99ff99',
					'#DB504A',
				],
				borderColor: '#1C1C1C',
				data: [<?php echo $vacinados ?>, <?php echo $nao_vacinados ?>],

			}]
		};

		const config2 = {
			type: 'pie',
			data: data2,
			options: {}
		};

		// FIM DADOS PARA VACINADOS
		// DADOS PARA DOSES

		const labels3 = [
			'Primeira dose',
			'Segunda dose',
			'Terceira dose',
			'Dose única'
		];
		const data3 = {
			labels: labels3,
			datasets: [{
				label: 'Doses',
				backgroundColor: [
					'#254E70',
					'#37718E',
					'#8EE3EF',
					'#AEF3E7'
				],
				borderColor: '#1C1C1C',
				data: [
					<?php echo $n_primeira_dose ?>,
                    <?php echo $n_segunda_dose ?>,
                    <?php echo $n_terceira_dose ?>,
                    <?php echo $n_dose_unica ?>],

			}]
		};

		const config3 = {
			type: 'pie',
			data: data3,
			options: {}
		};

		//FIM DOSES

		// GRÁFICOS
		const myChart = new Chart(
			document.getElementById('myChart'),
			config
		);

		const vacinados = new Chart(
			document.getElementById('vacinados'),
			config2
		);

		const dose = new Chart(
			document.getElementById('dose'),
			config3
		);
	</script>
	</body>

</html>