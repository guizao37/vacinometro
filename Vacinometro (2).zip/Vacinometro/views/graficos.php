<?php

include_once('../models/config.php');

// NÚMERO DE VACINADOS
$sim = "SELECT * FROM usuarios WHERE vacinado = 'sim' ";
$vacinados = mysqli_num_rows($conexao->query($sim));

// NÚMERO DE NÃO VACINADOS
$nao = "SELECT * FROM usuarios WHERE vacinado = 'nao' ";
$nao_vacinados = mysqli_num_rows($conexao->query($nao));

// ASTRAZENECA
$astrazeneca = "SELECT * FROM usuarios WHERE fabricante = 'Astrazeneca / Oxford' ";
$n_astrazeneca = mysqli_num_rows($conexao->query($astrazeneca));

// PFIZER
$pfizer = "SELECT * FROM usuarios WHERE fabricante = 'Pfizer' ";
$n_pfizer = mysqli_num_rows($conexao->query($pfizer));

// CORONAVAC
$coronavac = "SELECT * FROM usuarios WHERE fabricante = 'Coronavac' ";
$n_coronavac = mysqli_num_rows($conexao->query($coronavac));

// JANSSEN
$janssen = "SELECT * FROM usuarios WHERE fabricante = 'Janssen' ";
$n_janssen = mysqli_num_rows($conexao->query($janssen));

// OUTRAS
$outras = "SELECT * FROM usuarios WHERE fabricante = 'Outra' ";
$n_outras = mysqli_num_rows($conexao->query($outras));

// PRIMEIRA DOSE
$primeira_dose = "SELECT * FROM usuarios WHERE dose = 'Primeira dose' ";
$n_primeira_dose = mysqli_num_rows($conexao->query($primeira_dose));

// SEGUNDA DOSE
$segunda_dose = "SELECT * FROM usuarios WHERE dose = 'Segunda dose' ";
$n_segunda_dose = mysqli_num_rows($conexao->query($segunda_dose));

// TERCEIRA DOSE
$terceira_dose = "SELECT * FROM usuarios WHERE dose = 'Terceira dose' ";
$n_terceira_dose = mysqli_num_rows($conexao->query($terceira_dose));

// DOSE UNICA
$dose_unica = "SELECT * FROM usuarios WHERE dose = 'Dose única' ";
$n_dose_unica = mysqli_num_rows($conexao->query($dose_unica));

?>

<script>
	const labels = [
		'Oxford / Astrazeneca',
		'Pfizer',
		'Coronavac',
		'Janssen',
		'Outras',
	];
	const data = {
		labels: labels,
		datasets: [{
			label: 'My First dataset',
			backgroundColor: [
				'orange',
				'blue',
				'green',
				'red',
				'white'
			],
			borderColor: 'black',
			color: 'black',
			data: [<?php echo $n_astrazeneca ?>, <?php echo $n_pfizer ?>, <?php echo $n_coronavac ?>, <?php echo $n_janssen ?>, <?php echo $n_outras ?>],

		}]
	};
	const config = {
		type: 'pie',
		data: data,
		options: {
			font: {
				color: 'orange',
			}
		}
	};
	const myChart = new Chart(
		document.getElementById('myChart'),
		config
	);

	const vacinados = new Chart(
		document.getElementById('vacinados')
	)
</script>