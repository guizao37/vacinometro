<?php
    session_start();
    if ((!isset($_SESSION['email']) == true ) and (!isset($_SESSION['senha']) == true))
    {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        header(
            'Location: index.php'
        );
    }
    else {
        $logado = $_SESSION['email'];
    }
?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Vacinômetro PUC-SP</title>
		<link rel="stylesheet" type="text/css" href="../estilo/style.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.6.0/chart.min.js"></script>
		
		<script>

		</script>

	</head>
	<body>
		<div id="cabecalho">
			<img src="../imagens/puc.jpg" width="200px">
				<div id="menu">
					<form method="POST" action="../controllers/sair.php">	
                    <a href="sistema.php">INÍCIO</a>
					<a href="dados.php">DADOS</a>
					<a href="conta.php">CONTA</a>
                    <input type="submit" name="sair" value="SAIR">
					</form>
				</div>
			
		</div>
		<div id="conteudo">
			<br>
			<strong><h1>Sobre o Vacinômetro</h1></strong><br><br>
			<p>
				Este é um projeto realizado com o intuito de reunir informações referentes a vacinação contra a <span style="color: red;">covid-19</span> das pessoas que frequentam a PUC-SP.
			</p>
			<br>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras bibendum tempus turpis, eget facilisis nisi faucibus ac. Proin venenatis et dui nec ultricies. Sed a dolor venenatis, feugiat neque id, efficitur odio. Duis molestie ligula eget bibendum finibus. Nunc viverra laoreet dui, et malesuada elit faucibus ac. Ut pretium odio eu nibh dictum, ultrices pulvinar arcu maximus. Phasellus tempor nulla at felis mollis laoreet. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu lobortis purus, vel facilisis eros.
			</p>
			<br>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras bibendum tempus turpis, eget facilisis nisi faucibus ac. Proin venenatis et dui nec ultricies. Sed a dolor venenatis, feugiat neque id, efficitur odio. Duis molestie ligula eget bibendum finibus. Nunc viverra laoreet dui, et malesuada elit faucibus ac. Ut pretium odio eu nibh dictum, ultrices pulvinar arcu maximus. Phasellus tempor nulla at felis mollis laoreet. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu lobortis purus, vel facilisis eros.</p>
			
		</div>
	</body>
	</html>